from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo

from app.config import load_settings

router = Router()


def main_keyboard() -> InlineKeyboardMarkup | None:
    settings = load_settings()
    if not settings.webapp_url:
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Открыть SharipovAI", web_app=WebAppInfo(url=settings.webapp_url))],
            [InlineKeyboardButton(text="💬 AI чат", callback_data="ai_chat")],
        ]
    )


@router.message(CommandStart())
async def start_handler(message: Message) -> None:
    name = message.from_user.first_name if message.from_user else "друг"
    await message.answer(
        f"Привет, {name}! 👋\n\n"
        "Это SharipovAI — демо-панель для AI-трейдинга в стиле мобильного приложения.\n"
        "Открой интерфейс кнопкой ниже.",
        reply_markup=main_keyboard(),
    )


@router.message(Command("app"))
async def app_handler(message: Message) -> None:
    await message.answer("Открыть приложение:", reply_markup=main_keyboard())


@router.message(Command("help"))
async def help_handler(message: Message) -> None:
    await message.answer(
        "Команды:\n"
        "/start — главное меню\n"
        "/app — открыть Mini App\n"
        "/help — помощь\n\n"
        "Пока данные демо. Следующим шагом можно подключить биржу, AI-анализ и базу сделок."
    )


@router.message(F.text)
async def chat_handler(message: Message) -> None:
    text = (message.text or "").lower()
    if "btc" in text or "бит" in text:
        answer = "BTC выглядит сильнее рынка: тренд вверх, поддержка около 66 800, цель 68 500. Уверенность AI: 82%."
    elif "риск" in text:
        answer = "Для демо-режима можно держать риск 2% на сделку, максимальную просадку 10%, минимальную уверенность AI 78%."
    else:
        answer = "SharipovAI анализирует рынок. Лучшие демо-пары: BTC/USDT Long, SOL/USDT Long, ETH/USDT Short. Уверенность AI: 78%."
    await message.answer(answer)
