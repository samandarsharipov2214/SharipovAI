from dataclasses import dataclass
import os
from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    bot_token: str
    webapp_url: str


def load_settings() -> Settings:
    load_dotenv()
    token = os.getenv("BOT_TOKEN", "").strip()
    webapp_url = os.getenv("WEBAPP_URL", "").strip().rstrip("/")
    if not token:
        raise RuntimeError("BOT_TOKEN не найден. Создай .env по примеру .env.example")
    return Settings(bot_token=token, webapp_url=webapp_url)
