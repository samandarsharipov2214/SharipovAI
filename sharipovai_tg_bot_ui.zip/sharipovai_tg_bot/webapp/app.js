const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();

function openTab(tab) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.querySelector(`#screen-${tab}`).classList.add('active');
  document.querySelectorAll('.bottom-nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
}

document.querySelectorAll('.bottom-nav button').forEach(button => {
  button.addEventListener('click', () => openTab(button.dataset.tab));
});
