# SharipovAI Telegram Bot + Mini App

Заготовка Telegram-бота и мобильного Mini App интерфейса в стиле картинки: тёмный трейдинг-дашборд, демо-счёт, сделки, риск-настройки и AI чат.

## Что внутри

- `app/bot.py` — запуск Telegram-бота на aiogram 3
- `app/handlers/basic.py` — команды `/start`, `/app`, `/help` и простые AI-ответы
- `webapp/index.html` — интерфейс Mini App
- `webapp/styles.css` — дизайн под SharipovAI
- `webapp/app.js` — переключение вкладок и Telegram WebApp init

## Запуск бота

```bash
cp .env.example .env
pip install -r requirements.txt
python -m app.bot
```

В `.env` вставь токен от @BotFather.

## Как открыть Mini App в Telegram

Telegram требует HTTPS-ссылку. Варианты:

1. Залить папку `webapp` на хостинг/Vercel/Netlify.
2. Или временно запустить локально и открыть через HTTPS-туннель, например ngrok/cloudflared.
3. В `.env` указать:

```env
WEBAPP_URL=https://your-domain.com
```

После этого команда `/start` покажет кнопку **Открыть SharipovAI**.

## Следующий шаг

Можно подключить реальные данные: Binance/Bybit API, базу сделок, авторизацию Telegram-пользователя и настоящий AI-анализ.
